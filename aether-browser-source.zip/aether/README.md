# Aether Browser
"Aether: Tarayıcı değil, kendi internet evrenin."

## Paketleri üret (en kolay yol)
1. Bu klasörü bir GitHub deposuna yükle.
2. Actions → build-aether → Run workflow.
3. İş bitince Artifacts bölümünden indir: linux (.deb .rpm .AppImage), windows (.exe), macos (.dmg), android (.apk).

## Yerelde
    npm install && npm start          # çalıştır
    npm run dist:linux                # .deb .rpm .AppImage  (Linux'ta)
    npm run dist:win                  # .exe (Windows'ta)
    npm run dist:mac                  # .dmg (macOS'ta)
    cd android && gradle assembleDebug

## Tor
Linux paketleri `tor` paketine bağımlıdır (otomatik kurulur). Windows/macOS için Tor Expert Bundle içeriğini `tor/` klasörüne koy.
Android sürümü Orbot (SOCKS 9050) üzerinden Tor kullanır.

## Reklam engelleme
Yerleşik liste küçüktür. `userData/blocklist.txt` dosyasına hosts biçiminde (örn. StevenBlack) liste ekleyebilirsin.
