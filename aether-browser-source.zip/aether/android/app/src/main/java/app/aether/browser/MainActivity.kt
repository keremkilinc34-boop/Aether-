package app.aether.browser

import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var url: EditText
    private var blocked = 0
    private var tor = false
    private val hosts = setOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "googletagmanager.com", "adnxs.com", "criteo.com", "outbrain.com", "taboola.com", "scorecardresearch.com",
        "amazon-adsystem.com", "facebook.net", "hotjar.com", "mixpanel.com", "moatads.com", "adsrvr.org", "pubmatic.com", "rubiconproject.com")

    private fun isBlocked(h: String): Boolean {
        val p = h.split('.')
        for (i in 0 until p.size - 1) if (p.subList(i, p.size).joinToString(".") in hosts) return true
        return false
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0B0D14")) }
        val bar = LinearLayout(this).apply { setPadding(16, 16, 16, 16) }
        url = EditText(this).apply {
            hint = "Ara veya adres gir"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); maxLines = 1; inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        val shield = Button(this).apply { text = "🛡0" }
        val torBtn = Button(this).apply { text = "Tor"; setOnClickListener { toggleTor(this) } }
        bar.addView(url); bar.addView(shield); bar.addView(torBtn)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.safeBrowsingEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    if (isBlocked(r.url.host ?: "")) { blocked++; runOnUiThread { shield.text = "🛡$blocked" }
                        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0))) }
                    return null
                }
                override fun onPageFinished(v: WebView, u: String) { url.setText(u) }
            }
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        root.addView(bar); root.addView(web); setContentView(root)
        go(intent?.dataString ?: "https://duckduckgo.com")
    }

    private fun go(raw: String) {
        val t = raw.trim()
        val u = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains('.') && !t.contains(' ') -> (if (t.endsWith(".onion")) "http://" else "https://") + t
            else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(t, "utf-8")
        }
        web.loadUrl(u)
    }

    // Tor: cihazda Orbot (SOCKS 9050) çalışıyorsa trafik oradan geçer.
    private fun toggleTor(btn: Button) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) { Toast.makeText(this, "Bu WebView proxy desteklemiyor", Toast.LENGTH_LONG).show(); return }
        val ex = Executor { it.run() }
        if (!tor) {
            ProxyController.getInstance().setProxyOverride(ProxyConfig.Builder().addProxyRule("socks5://127.0.0.1:9050").build(), ex) { btn.text = "Tor ✓"; web.reload() }
            Toast.makeText(this, "Orbot'un çalıştığından emin olun", Toast.LENGTH_SHORT).show()
        } else ProxyController.getInstance().clearProxyOverride(ex) { btn.text = "Tor"; web.reload() }
        tor = !tor
    }

    override fun onKeyDown(k: Int, e: KeyEvent?): Boolean { if (k == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true }; return super.onKeyDown(k, e) }
}
