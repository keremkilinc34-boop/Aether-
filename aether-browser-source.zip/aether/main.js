'use strict';
const { app, BrowserWindow, WebContentsView, ipcMain, session, Menu, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const adblock = require('./src/adblock');
const tor = require('./src/tor');

if (process.platform === 'linux') app.commandLine.appendSwitch('no-sandbox');
app.commandLine.appendSwitch('enable-features', 'WebRTCPipeWireCapturer');

const UI_DIR = path.join(__dirname, 'ui');
const UI_PREFIX = pathToFileURL(UI_DIR).href;
const PRELOAD = path.join(__dirname, 'preload.js');
const PAGES = { 'aether://newtab': 'newtab.html', 'aether://settings': 'settings.html' };
const TOR_UA = 'Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0';

const DEFAULTS = {
  theme: 'aether', mode: 'aether', radius: 12, blur: 16, opacity: 1, customCss: '',
  adblock: true, httpsOnly: true, doh: true, perf: 'normal', sleepMinutes: 5,
  torAll: false, torCountry: '', torBridge: '', engine: 'https://duckduckgo.com/?q=', perms: {},
};
let settings = { ...DEFAULTS };
let win, ui, tabs = [], activeId = null, nextId = 1, overlay = false, blocked = 0;
let rect = { x: 0, y: 90, width: 900, height: 600 };
let history = [];
const dataFile = (n) => path.join(app.getPath('userData'), n);

function load() {
  try { settings = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(dataFile('settings.json'), 'utf8')) }; } catch {}
  try { history = JSON.parse(fs.readFileSync(dataFile('history.json'), 'utf8')); } catch {}
}
const saveSettings = () => fs.writeFileSync(dataFile('settings.json'), JSON.stringify(settings));
const saveHistory = () => fs.writeFileSync(dataFile('history.json'), JSON.stringify(history.slice(-2000)));

const normal = () => session.fromPartition('persist:aether');
const torSes = () => session.fromPartition('aether-tor');

function internalPageUrl(u) { return pathToFileURL(path.join(UI_DIR, PAGES[u])).href; }
function display(url) {
  for (const k of Object.keys(PAGES)) if (url === internalPageUrl(k)) return k;
  return url;
}
function resolveInput(raw) {
  const t = String(raw || '').trim();
  if (!t) return internalPageUrl('aether://newtab');
  if (PAGES[t]) return internalPageUrl(t);
  if (/^(https?|file):\/\//i.test(t)) return t;
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(t) && !/\s/.test(t)) return (/\.onion/.test(t) ? 'http://' : 'https://') + t;
  if (/^localhost(:\d+)?/.test(t)) return 'http://' + t;
  return settings.engine + encodeURIComponent(t);
}

// ---------- ağ katmanı: reklam engelleme, HTTPS, performans, izinler ----------
function hook(ses, isTor) {
  ses.webRequest.onBeforeRequest((d, cb) => {
    const url = d.url;
    if (!/^https?:/.test(url)) return cb({});
    const u = new URL(url);
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname) || u.hostname.endsWith('.onion');
    if (settings.httpsOnly && d.resourceType === 'mainFrame' && u.protocol === 'http:' && !local)
      return cb({ redirectURL: url.replace(/^http:/, 'https:') });
    if (settings.adblock && adblock.shouldBlock(url, d.resourceType)) { blocked++; push('blocked', blocked); return cb({ cancel: true }); }
    if (settings.perf !== 'normal' && ['media', 'font'].includes(d.resourceType)) return cb({ cancel: true });
    if (settings.perf === 'ultra' && d.resourceType === 'image') return cb({ cancel: true });
    cb({});
  });
  ses.webRequest.onHeadersReceived((d, cb) => cb({ responseHeaders: d.responseHeaders }));
  ses.setPermissionRequestHandler(async (wc, perm, cb, det) => {
    if (!['media', 'geolocation', 'notifications', 'clipboard-read'].includes(perm)) return cb(false);
    const origin = (() => { try { return new URL(det.requestingUrl).origin; } catch { return ''; } })();
    const key = origin + '|' + perm;
    if (key in settings.perms) return cb(settings.perms[key]);
    const r = await dialog.showMessageBox(win, { type: 'question', buttons: ['İzin ver', 'Engelle'], defaultId: 1, message: `${origin} "${perm === 'media' ? 'kamera/mikrofon' : perm}" izni istiyor` });
    settings.perms[key] = r.response === 0; saveSettings(); cb(r.response === 0);
  });
  if (isTor) ses.setUserAgent(TOR_UA);
}

async function applyProxy() {
  const r = tor.status().state === 'on' ? tor.proxyRules : '';
  await torSes().setProxy(r ? { proxyRules: r, proxyBypassRules: '<-loopback>' } : { mode: 'direct' });
  await normal().setProxy(settings.torAll && r ? { proxyRules: r, proxyBypassRules: '<-loopback>' } : { mode: 'direct' });
}
async function ensureTor() {
  if (tor.status().state === 'on') return;
  await tor.start({ country: settings.torCountry, bridge: settings.torBridge });
  await applyProxy();
}

// ---------- sekmeler ----------
const colorOf = (u) => { let h = 0; try { for (const c of new URL(u).hostname) h = (h * 31 + c.charCodeAt(0)) % 360; } catch {} return `hsl(${h} 70% 60%)`; };
const isInternal = (t) => t.url.startsWith(UI_PREFIX);

function makeView(t) {
  const view = new WebContentsView({ webPreferences: { partition: t.tor ? 'aether-tor' : 'persist:aether', contextIsolation: true, sandbox: true, nodeIntegration: false, preload: PRELOAD } });
  const wc = view.webContents;
  wc.setWindowOpenHandler(({ url }) => { newTab(url, { tor: t.tor }); return { action: 'deny' }; });
  const upd = () => { t.url = wc.getURL() || t.url; t.title = wc.getTitle() || t.title; sync(); };
  wc.on('did-navigate', () => { upd(); if (!isInternal(t) && !t.tor) { history.push({ t: t.title, u: t.url, ts: Date.now() }); saveHistory(); } });
  wc.on('did-navigate-in-page', upd);
  wc.on('page-title-updated', upd);
  wc.on('did-start-loading', () => { t.loading = true; sync(); });
  wc.on('did-stop-loading', () => { t.loading = false; upd(); if (settings.adblock && !isInternal(t)) wc.insertCSS(adblock.COSMETIC).catch(() => {}); });
  wc.on('page-favicon-updated', (_e, f) => { t.favicon = f[0]; sync(); });
  wc.on('context-menu', (_e, p) => {
    Menu.buildFromTemplate([
      p.linkURL && { label: 'Bağlantıyı yeni sekmede aç', click: () => newTab(p.linkURL, { tor: t.tor }) },
      p.linkURL && { label: 'Bağlantıyı Tor sekmesinde aç', click: () => newTab(p.linkURL, { tor: true }) },
      p.selectionText && { role: 'copy', label: 'Kopyala' },
      { label: 'Geri', enabled: wc.canGoBack(), click: () => wc.goBack() },
      { label: 'Yenile', click: () => wc.reload() },
      { label: 'Öğeyi incele', click: () => wc.inspectElement(p.x, p.y) },
    ].filter(Boolean)).popup();
  });
  win.contentView.addChildView(view);
  t.view = view; t.sleeping = false;
  return view;
}

async function newTab(raw, opts = {}) {
  const t = { id: nextId++, tor: !!opts.tor, url: resolveInput(raw), title: 'Yeni sekme', favicon: '', loading: false, view: null, sleeping: false, last: Date.now() };
  tabs.push(t);
  if (t.tor || /\.onion/.test(t.url)) { if (/\.onion/.test(t.url)) t.tor = true; try { await ensureTor(); } catch (e) { t.url = internalPageUrl('aether://newtab'); } }
  makeView(t).webContents.loadURL(t.url);
  activate(t.id);
  return t.id;
}
function activate(id) {
  const t = tabs.find(x => x.id === id); if (!t) return;
  activeId = id; t.last = Date.now();
  if (!t.view) { makeView(t).webContents.loadURL(t.url); }
  layout(); sync();
}
function closeTab(id) {
  const i = tabs.findIndex(x => x.id === id); if (i < 0) return;
  const t = tabs[i];
  if (t.view) { win.contentView.removeChildView(t.view); t.view.webContents.close(); }
  tabs.splice(i, 1);
  if (!tabs.length) return newTab('aether://newtab');
  if (activeId === id) activate(tabs[Math.max(0, i - 1)].id); else sync();
}
function sleep(t) {
  if (!t.view || t.id === activeId) return;
  t.url = t.view.webContents.getURL() || t.url;
  win.contentView.removeChildView(t.view); t.view.webContents.close(); t.view = null; t.sleeping = true;
}
function layout() {
  for (const t of tabs) if (t.view) {
    const show = t.id === activeId && !overlay;
    t.view.setVisible(show);
    if (show) t.view.setBounds({ x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) });
  }
}
const active = () => tabs.find(t => t.id === activeId);
function sync() {
  push('tabs', tabs.map(t => ({
    id: t.id, title: t.title, url: display(t.url), favicon: t.favicon, loading: t.loading, active: t.id === activeId,
    sleeping: t.sleeping, tor: t.tor, color: colorOf(t.url),
    back: !!t.view && t.view.webContents.canGoBack(), fwd: !!t.view && t.view.webContents.canGoForward(),
  })));
}
function push(ch, ...a) {
  if (ui && !ui.isDestroyed()) ui.send(ch, ...a);
  for (const t of tabs) if (t.view && isInternal(t)) t.view.webContents.send(ch, ...a);
}

// ---------- pencere ----------
function createWindow() {
  win = new BrowserWindow({ width: 1280, height: 820, minWidth: 760, minHeight: 500, backgroundColor: '#0b0d14', title: 'Aether', webPreferences: { preload: PRELOAD, contextIsolation: true, sandbox: true } });
  ui = win.webContents;
  win.setMenuBarVisibility(false);
  win.setOpacity(settings.opacity);
  ui.loadFile(path.join(UI_DIR, 'index.html'));
  ui.once('did-finish-load', () => { newTab('aether://newtab'); });
  win.on('resize', () => {});
  win.on('closed', () => { tor.stop(); });
  const accel = (label, accelerator, fn) => ({ label, accelerator, click: fn });
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Aether', submenu: [
      accel('Yeni sekme', 'CmdOrCtrl+T', () => newTab('aether://newtab')),
      accel('Yeni Tor sekmesi', 'CmdOrCtrl+Shift+T', () => newTab('aether://newtab', { tor: true })),
      accel('Sekmeyi kapat', 'CmdOrCtrl+W', () => closeTab(activeId)),
      accel('Adres çubuğu', 'CmdOrCtrl+L', () => ui.send('cmd', 'focus-url')),
      accel('Komut paleti', 'CmdOrCtrl+K', () => ui.send('cmd', 'palette')),
      accel('Yenile', 'CmdOrCtrl+R', () => active()?.view?.webContents.reload()),
      accel('Tam ekran', 'F11', () => win.setFullScreen(!win.isFullScreen())),
      accel('Geliştirici araçları', 'F12', () => active()?.view?.webContents.openDevTools()),
      { role: 'quit', label: 'Çık' },
    ] },
    { label: 'Düzenle', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
  ]));
}

// ---------- IPC (yalnızca kendi ui/ sayfalarına açık) ----------
const trusted = (e) => (e.senderFrame?.url || '').startsWith(UI_PREFIX);
const H = (name, fn) => ipcMain.handle('a:' + name, (e, ...a) => (trusted(e) ? fn(...a) : null));

H('settings:get', () => settings);
H('settings:set', async (patch) => {
  settings = { ...settings, ...patch }; saveSettings();
  win.setOpacity(Number(settings.opacity) || 1);
  if ('doh' in patch) applyDoh();
  if ('torAll' in patch) { if (settings.torAll) { try { await ensureTor(); } catch {} } await applyProxy(); }
  push('settings', settings);
});
H('layout:rect', (r) => { rect = r; layout(); });
H('overlay', (v) => { overlay = !!v; layout(); });
H('tabs:get', () => sync());
H('tab:new', (u, o) => newTab(u || 'aether://newtab', o));
H('tab:close', (id) => closeTab(id));
H('tab:activate', (id) => activate(id));
H('tab:sleepOthers', () => { tabs.forEach(sleep); sync(); normal().clearCache(); });
H('nav', (action, input) => {
  const t = active(); if (!t) return;
  if (!t.view) makeView(t);
  const wc = t.view.webContents;
  if (action === 'back') wc.goBack(); else if (action === 'fwd') wc.goForward(); else if (action === 'reload') wc.reload();
  else if (action === 'go') { const u = resolveInput(input); if (/\.onion/.test(u)) { t.tor = true; ensureTor().then(() => wc.loadURL(u)); } else wc.loadURL(u); }
});
H('tor:status', () => tor.status());
H('tor:newid', async () => { await tor.newIdentity(); await torSes().clearStorageData(); await torSes().clearCache(); });
H('tor:stop', async () => { tor.stop(); settings.torAll = false; await applyProxy(); push('settings', settings); });
H('clear:all', async () => {
  for (const s of [normal(), torSes()]) { await s.clearStorageData(); await s.clearCache(); await s.clearAuthCache(); }
  history = []; saveHistory(); settings.perms = {}; saveSettings();
});
H('metrics', () => app.getAppMetrics().map(m => ({ type: m.type, cpu: m.cpu.percentCPUUsage, mem: Math.round((m.memory.workingSetSize || 0) / 1024) })));
H('palette', (q) => {
  q = String(q || '').toLowerCase();
  const out = [];
  const cmds = [
    ['Yeni sekme', () => newTab('aether://newtab')], ['Yeni Tor sekmesi', () => newTab('aether://newtab', { tor: true })],
    ['Ayarlar', () => newTab('aether://settings')], ['RAM temizle (sekmeleri uyut)', () => { tabs.forEach(sleep); sync(); normal().clearCache(); }],
    ['Tor: yeni kimlik', async () => { await tor.newIdentity(); }], ['Tüm verileri sil', async () => { for (const s of [normal(), torSes()]) { await s.clearStorageData(); await s.clearCache(); } history = []; saveHistory(); }],
  ];
  cmds.forEach(([n, fn], i) => { if (n.toLowerCase().includes(q)) out.push({ kind: 'cmd', label: n, i }); });
  tabs.forEach(t => { if ((t.title + t.url).toLowerCase().includes(q)) out.push({ kind: 'tab', label: t.title, sub: display(t.url), id: t.id }); });
  if (q) history.slice(-500).reverse().forEach(h => { if (out.length < 14 && (h.t + h.u).toLowerCase().includes(q)) out.push({ kind: 'url', label: h.t || h.u, sub: h.u }); });
  paletteCmds = cmds;
  return out.slice(0, 14);
});
let paletteCmds = [];
H('palette:run', (item) => {
  if (item.kind === 'cmd') paletteCmds[item.i]?.[1]();
  else if (item.kind === 'tab') activate(item.id);
  else if (item.kind === 'url') newTab(item.sub);
});

function applyDoh() {
  try { app.configureHostResolver({ secureDnsMode: settings.doh ? 'secure' : 'automatic', secureDnsServers: ['https://cloudflare-dns.com/dns-query'] }); } catch {}
}

app.whenReady().then(() => {
  load();
  adblock.loadExtra(app.getPath('userData'));
  hook(normal(), false); hook(torSes(), true);
  tor.onStatus((s) => push('tor', s));
  applyDoh();
  createWindow();
});
app.on('window-all-closed', () => { tor.stop(); app.quit(); });
setInterval(() => { const lim = (settings.sleepMinutes || 5) * 60000; tabs.forEach(t => { if (t.id !== activeId && t.view && Date.now() - t.last > lim) sleep(t); }); sync(); }, 30000);
