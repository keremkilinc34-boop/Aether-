Windows/macOS icin Tor Expert Bundle icerigini (tor / tor.exe + data) bu klasore koyun; pakete otomatik girer. Linux paketleri 'tor' paketine bagimlidir.
