'use strict';
const { spawn } = require('child_process');
const net = require('net');
const fs = require('fs');
const path = require('path');
const { app } = require('electron');

const SOCKS = 9150, CTRL = 9151;
let proc = null;
let state = { state: 'off', progress: 0, msg: '' };
let listener = () => {};

function onStatus(fn) { listener = fn; }
function set(s) { state = { ...state, ...s }; listener(state); }
function status() { return state; }

function binary() {
  const exe = process.platform === 'win32' ? 'tor.exe' : 'tor';
  const bundled = path.join(process.resourcesPath || '', 'tor', exe);
  const bundled2 = path.join(process.resourcesPath || '', 'tor', 'tor', exe);
  if (fs.existsSync(bundled)) return bundled;
  if (fs.existsSync(bundled2)) return bundled2;
  return 'tor';
}

function start(opts = {}) {
  if (proc) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const dataDir = path.join(app.getPath('userData'), 'tor-data');
    fs.mkdirSync(dataDir, { recursive: true });
    const args = ['--SocksPort', String(SOCKS), '--ControlPort', String(CTRL), '--DataDirectory', dataDir, '--ClientOnly', '1', '--Log', 'notice stdout'];
    if (opts.country) args.push('--ExitNodes', `{${opts.country.toLowerCase()}}`, '--StrictNodes', '1');
    if (opts.bridge) args.push('--UseBridges', '1', '--Bridge', opts.bridge);
    set({ state: 'starting', progress: 0, msg: 'Tor başlatılıyor…' });
    try { proc = spawn(binary(), args); }
    catch (e) { set({ state: 'error', msg: String(e.message) }); return reject(e); }
    let done = false;
    const fail = (m) => { if (done) return; done = true; proc = null; set({ state: 'error', msg: m }); reject(new Error(m)); };
    proc.on('error', () => fail('Tor bulunamadı. "tor" paketini kurun (Linux) veya tor/ klasörüne Tor Expert Bundle koyun.'));
    proc.on('exit', () => { proc = null; if (!done) fail('Tor beklenmedik şekilde kapandı'); else set({ state: 'off', progress: 0, msg: '' }); });
    proc.stdout.on('data', (d) => {
      const m = /Bootstrapped (\d+)%/.exec(String(d));
      if (m) {
        const p = Number(m[1]);
        set({ progress: p, msg: `Tor bağlanıyor %${p}` });
        if (p >= 100 && !done) { done = true; set({ state: 'on', msg: 'Tor bağlı' }); resolve(); }
      }
    });
    setTimeout(() => fail('Tor zaman aşımı (90 sn). Bridge deneyin.'), 90000);
  });
}

function stop() { if (proc) { proc.kill(); proc = null; } set({ state: 'off', progress: 0, msg: '' }); }

function newIdentity() {
  return new Promise((resolve) => {
    const s = net.connect(CTRL, '127.0.0.1', () => s.write('AUTHENTICATE ""\r\nSIGNAL NEWNYM\r\nQUIT\r\n'));
    s.on('data', () => {}); s.on('close', () => resolve(true)); s.on('error', () => resolve(false));
  });
}

module.exports = { start, stop, newIdentity, status, onStatus, proxyRules: `socks5://127.0.0.1:${SOCKS}` };
