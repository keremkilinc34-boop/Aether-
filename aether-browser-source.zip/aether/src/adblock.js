'use strict';
const fs = require('fs');
const path = require('path');

const HOSTS = new Set(`doubleclick.net googlesyndication.com googleadservices.com google-analytics.com googletagmanager.com
googletagservices.com adservice.google.com pagead2.googlesyndication.com adnxs.com adsrvr.org criteo.com criteo.net outbrain.com
taboola.com scorecardresearch.com quantserve.com rubiconproject.com pubmatic.com openx.net casalemedia.com advertising.com
amazon-adsystem.com facebook.net connect.facebook.net hotjar.com mixpanel.com segment.io fullstory.com mouseflow.com
yandex.ru/metrika mc.yandex.ru moatads.com adform.net smartadserver.com 2mdn.net zedo.com popads.net propellerads.com
exoclick.com adsterra.com mgid.com revcontent.com bidswitch.net sharethrough.com tapad.com bluekai.com demdex.net
krxd.net chartbeat.com newrelic.com nr-data.net branch.io appsflyer.com adjust.com`.split(/\s+/).filter(Boolean));

const PATTERNS = [/\/ads?\//i, /\/adserver/i, /[?&]ad_?(unit|slot|id)=/i, /\/banners?\//i, /\/pagead\//i, /\/tracking\//i, /\/analytics\.js/i, /\/gtag\/js/i];
const COSMETIC = `[id^="google_ads"],[class*="adsbygoogle"],ins.adsbygoogle,[id*="ad-container"],[class*="ad-banner"],[class*="sponsored"],iframe[src*="doubleclick"]{display:none!important}`;

let extra = new Set();
function loadExtra(dir) {
  try {
    const f = path.join(dir, 'blocklist.txt');
    if (!fs.existsSync(f)) return;
    for (const line of fs.readFileSync(f, 'utf8').split('\n')) {
      const t = line.trim();
      if (!t || t.startsWith('#')) continue;
      const parts = t.split(/\s+/);
      extra.add((parts.length > 1 ? parts[1] : parts[0]).toLowerCase());
    }
  } catch {}
}

function hostBlocked(h) {
  const parts = h.split('.');
  for (let i = 0; i < parts.length - 1; i++) {
    const s = parts.slice(i).join('.');
    if (HOSTS.has(s) || extra.has(s)) return true;
  }
  return false;
}

function shouldBlock(url, type) {
  let u;
  try { u = new URL(url); } catch { return false; }
  if (!/^https?:$/.test(u.protocol)) return false;
  if (hostBlocked(u.hostname)) return true;
  if (type !== 'mainFrame' && PATTERNS.some(r => r.test(u.pathname + u.search))) return true;
  return false;
}

module.exports = { shouldBlock, loadExtra, COSMETIC };
