const THEMES = {
  aether: { bg: '#0b0d14', panel: '#141826', fg: '#e8ecff', dim: '#8d96b8', accent: '#5b8cff', accent2: '#ff8a3d' },
  amoled: { bg: '#000000', panel: '#0a0a0a', fg: '#f2f2f2', dim: '#8a8a8a', accent: '#00e5a8', accent2: '#7c4dff' },
  light:  { bg: '#eef0f7', panel: '#ffffff', fg: '#1b1f2a', dim: '#69708a', accent: '#3b6cff', accent2: '#ff7a1a' },
  zen:    { bg: '#1c1b1a', panel: '#262422', fg: '#ece7df', dim: '#a39b8f', accent: '#d9a066', accent2: '#8fb996' },
  oyun:   { bg: '#0d0221', panel: '#190535', fg: '#f0e6ff', dim: '#a08cc8', accent: '#ff2a6d', accent2: '#05d9e8' },
  okyanus:{ bg: '#06141c', panel: '#0c222e', fg: '#dff6ff', dim: '#7fb0c4', accent: '#27c6e0', accent2: '#7be0a5' },
  rgb:    { bg: '#0a0a10', panel: '#14141e', fg: '#f4f4ff', dim: '#9a9ab8', accent: '#ff3b6b', accent2: '#3bd1ff' },
};
let _rgb = null, _css = null;
function applyTheme(s) {
  let name = s.theme;
  if (name === 'auto') { const h = new Date().getHours(); name = h >= 7 && h < 19 ? 'light' : 'aether'; }
  const t = THEMES[name] || THEMES.aether, r = document.documentElement;
  for (const k in t) r.style.setProperty('--' + k, t[k]);
  r.style.setProperty('--radius', s.radius + 'px');
  r.style.setProperty('--blur', s.blur + 'px');
  r.dataset.mode = s.mode; r.dataset.theme = name;
  clearInterval(_rgb);
  if (name === 'rgb') { let h = 0; _rgb = setInterval(() => { h = (h + 2) % 360; r.style.setProperty('--accent', `hsl(${h} 90% 60%)`); r.style.setProperty('--accent2', `hsl(${(h + 120) % 360} 90% 60%)`); }, 60); }
  if (!_css) { _css = document.createElement('style'); document.head.appendChild(_css); }
  _css.textContent = s.customCss || '';
}
async function initTheme(extra) {
  const s = await aether.invoke('settings:get'); applyTheme(s); extra && extra(s);
  aether.on('settings', (n) => { applyTheme(n); extra && extra(n); });
  return s;
}
